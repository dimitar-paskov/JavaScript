function attachEvents() {
    $('#btnLoadTowns').click(function () {

       let source =
           {
               towns : $('#towns')
                        .val()
                        .split(', ')
                        .filter(function (el) { //filters any falsy elements - null, "", undefined etc.
                            return el;
                        })

            };


       if(source.towns.length === 0){
           return;
       }
        let template = Handlebars.compile($('#towns-template').html());

        let html = template(source);

        $('#root').empty();
        $('#root').append(html);

    });

}