$(() => {
    renderCatTemplate();

    function renderCatTemplate() {
        let template = Handlebars.compile($('#cat-template').html());

        let source = {
            cats: cats
        };

        let html = template(source);

        $('#allCats').append(html);
    }

    $('.btn').click(function () {

        if($(this).text() === 'Show status code'){
            let selector = $(this).parent().children()[1];
            $(selector).css('display', 'block');
            $(this).text('Hide status code');
        }
        else{
            let selector = $(this).parent().children()[1];
            $(selector).css('display', 'none');
            $(this).text('Show status code');
        }
    });

});
