$(() => {
    renderCatTemplate();

    function renderCatTemplate() {
        let source = $.get("catsTemplate.hbs").then((res) => {
            let template = Handlebars.compile(res);
            $("#allCats").html(template({cats}));
            Array.from($(".btn")).forEach((button) => $(button).on("click",showAndHideInfo));

            function showAndHideInfo(){
                let btn = $(this);
                if(btn.text() === "Show status code"){
                    btn.next().css("display","block");
                    btn.text("Hide status code");
                }
                else{
                    btn.next().css("display","none");
                    btn.text("Show status code");
                }
            }
        });
    }

})
